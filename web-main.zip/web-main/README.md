<p align="center">
  <img src="./static/img/logo motivo dark.svg" width="300"/>
  <br />
</p>

<p align="center">
  <a href="https://github.com/danibcorr/web/actions/workflows/workflow.yml"><img src="https://github.com/danibcorr/web/actions/workflows/workflow.yml/badge.svg"></a>
</p>

# Web

Hi there! 👋

I'm Dani, an Electronic Systems Engineer. Welcome to my personal page! Here, you'll find
a collection of projects I've been working on, along with additional content that I hope
you'll find interesting and relevant.

If you are interested in connecting, feel free to do so through my
[LinkedIn](https://www.linkedin.com/in/danibcorr/).

Shield: [![CC BY-NC 4.0][cc-by-nc-shield]][cc-by-nc]

Shield: [![CC BY-NC-SA 4.0][cc-by-nc-sa-shield]][cc-by-nc-sa]

This work is licensed under a
[Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License][cc-by-nc-sa].

[![CC BY-NC-SA 4.0][cc-by-nc-sa-image]][cc-by-nc-sa]

[cc-by-nc-sa]: http://creativecommons.org/licenses/by-nc-sa/4.0/
[cc-by-nc-sa-image]: https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png
[cc-by-nc-sa-shield]: https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg